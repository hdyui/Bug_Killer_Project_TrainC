/* =========================================================
 * customer.c - Cài đặt quản lý khách hàng
 * ========================================================= */

#include <stdio.h>
#include <string.h>
#include "customer.h"
#include "fileio.h"
#include "utils.h"
#include "constants.h"

/* --- Định nghĩa bộ nhớ toàn cục --- */
Customer customers[MAX_CUSTOMERS];
int      customerCount = 0;

/* =========================================================
 * KHỞI TẠO
 * ========================================================= */

void initCustomers(void) {
    /* TODO:
     * Gán customerCount = 0
     * Dùng memset để xoá toàn bộ mảng customers về 0
     */
}

/* =========================================================
 * THÊM KHÁCH HÀNG
 * ========================================================= */

int addCustomer(void) {
    /* TODO:
     * 1. Kiểm tra customerCount < MAX_CUSTOMERS (báo lỗi nếu đầy)
     * 2. Tạo con trỏ c = &customers[customerCount]
     * 3. Nhập và validate từng trường:
     *    a. Nhập fullName (không được rỗng)
     *    b. Nhập phoneNumber, gọi isValidPhone(); nếu không hợp lệ thì báo lỗi và hỏi lại
     *    c. Gọi findCustomerByPhone() để kiểm tra trùng; nếu trùng báo lỗi và return 0
     *    d. Nhập carPlate, gọi isValidPlate()
     *    e. Nhập carType (không được rỗng)
     * 4. Sinh customerId bằng generateCustomerId(customerCount + 1, ...)
     * 5. Gán c->orderCount = 0
     * 6. Tăng customerCount
     * 7. Gọi saveCustomers() để lưu file
     * 8. In thông báo thành công, return 1
     */
    return 0; /* placeholder */
}

/* =========================================================
 * SỬA KHÁCH HÀNG
 * ========================================================= */

int editCustomer(void) {
    /* TODO:
     * 1. Nhập SĐT cần sửa
     * 2. Gọi findCustomerByPhone() -> lấy index; nếu -1 thì báo không tìm thấy, return 0
     * 3. In thông tin hiện tại của khách (gọi printCustomer)
     * 4. Hiển thị menu chọn trường muốn sửa:
     *    [1] Sửa họ tên
     *    [2] Sửa biển số xe
     *    [3] Sửa loại xe
     *    [0] Huỷ
     * 5. Nhập giá trị mới cho trường được chọn (validate trước khi gán)
     * 6. Cập nhật dữ liệu trong mảng
     * 7. Gọi saveCustomers() để lưu file
     * 8. In thông báo thành công, return 1
     */
    return 0; /* placeholder */
}

/* =========================================================
 * TÌM KIẾM
 * ========================================================= */

int findCustomerByPhone(const char *phone) {
    /* TODO:
     * Duyệt vòng for từ 0 đến customerCount - 1
     * Nếu strcmp(customers[i].phoneNumber, phone) == 0 thì return i
     * Nếu không tìm thấy, return -1
     */
    return -1; /* placeholder */
}

int findCustomerByPlate(const char *plate) {
    /* TODO:
     * Duyệt vòng for từ 0 đến customerCount - 1
     * Dùng strCmpIgnoreCase(customers[i].carPlate, plate) == 0 thì return i
     * Nếu không tìm thấy, return -1
     */
    return -1; /* placeholder */
}

void searchCustomerMenu(void) {
    /* TODO:
     * 1. Hiển thị lựa chọn: [1] Tìm theo SĐT  [2] Tìm theo biển số
     * 2. Nhận lựa chọn và nhập từ khoá tương ứng
     * 3. Gọi findCustomerByPhone hoặc findCustomerByPlate
     * 4. Nếu tìm thấy: gọi printCustomer(&customers[index])
     * 5. Nếu không: gọi printError("Không tìm thấy khách hàng.")
     */
}

/* =========================================================
 * HIỂN THỊ
 * ========================================================= */

void printCustomer(const Customer *c) {
    /* TODO:
     * In từng trường của Customer theo định dạng gọn, có nhãn:
     *   Mã KH      : CU000001
     *   Họ tên     : ...
     *   SĐT        : ...
     *   Biển số    : ...
     *   Loại xe    : ...
     *   Số phiếu   : ...
     */
}

void listAllCustomers(void) {
    /* TODO:
     * 1. Kiểm tra customerCount == 0 -> in "Chưa có khách hàng nào." rồi return
     * 2. In header bảng: STT | Mã KH | Họ tên | SĐT | Biển số | Loại xe | Số phiếu
     * 3. Duyệt vòng for, in từng dòng theo định dạng bảng (%-width)
     * 4. In tổng số ở cuối
     */
}
